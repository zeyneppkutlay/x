/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 10:48:18 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/18 16:30:12 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	char	*ptr;

	ptr = (char *)s;
	while (*ptr)
	{
		if (*ptr == (unsigned char)c)
			return (ptr);
		ptr ++;
	}
	if (c == 0)
		return (ptr);
	return (NULL);
}

/*int main()
{
	char *s = "Zeynep Kutlay";
	//printf("%s", ft_strchr(s, 't'));
	char *p = s + 2;
	printf("%s - %s - %c",s+2 , p, *p);
	
	return (0);
}*/