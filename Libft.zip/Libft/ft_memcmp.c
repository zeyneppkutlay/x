/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 13:42:14 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/23 13:13:31 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
int	ft_memcmp(const void *dest, const void *src, size_t n)
{
	unsigned char	*d;
	unsigned char	*s;

	d = (unsigned char *)dest;
	s = (unsigned char *)src;
	while (n && *d == *s)
	{
		++ d;
		++ s;
		-- n;
	}
	if (n)
		return (*d - *s);
	else
		return (0);
}

/*int main()
{
	char s[] = "Zeynep";
	char d[] = "Zeynep Kutlay";
	printf("%d", ft_memcmp(d, s, 15));
	return (0);
}*/