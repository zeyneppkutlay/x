/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 13:10:36 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/18 17:13:08 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	char	*ptr;

	ptr = (char *)s;
	c = (unsigned char)c;
	while (n && *ptr != c)
	{
		ptr ++;
		n --;
	}
	if (n)
		return ((void *)ptr);
	else
		return (NULL);
}

/*int main()
{
	char s[] = "Zeynep Kutlay";
	printf("%s", ft_memchr(s, 't', 15));
	return (0);
}*/