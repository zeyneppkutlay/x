/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/08 16:54:42 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/23 13:00:26 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	i;
	size_t	j;
	char	*str;

	if (s)
	{
		if (start >= ft_strlen(s) || len == 0 || ft_strlen(s) == 0)
			return (ft_strdup(""));
		i = 0;
		while (i < len && s[i + start] != '\0')
			i ++;
		str = (char *)malloc((sizeof(char) * i) + 1);
		if (!(str))
			return (NULL);
		j = 0;
		while (j < i)
		{
			str[j] = s[start + j];
			j ++;
		}
		str[j] = '\0';
		return (str);
	}
	return (NULL);
}
/*int main() {
  char str[] = "Hello, World!";
  char *subs = ft_substr(str, 3, 3);
  printf("%s\n", subs);
  free(subs);
  return 0;
}*/