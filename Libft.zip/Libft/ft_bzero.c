/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/04 12:47:32 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/18 15:46:11 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_bzero(void *s, size_t	n)
{
	ft_memset(s, 0, n);
}

/*int main()
{
	char dizi[] = "Bilgisayar";
	ft_bzero(dizi, 2);
	printf("cdizi bellek içeriği: %s", dizi);

	return (0);
}*/