/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/04 13:42:25 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/22 17:39:42 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	size_t	i;
	char	*str;

	i = 0;
	str = (char *)b;
	while (i < len)
	{
		str[i] = c;
		i ++;
	}
	return (b);
}
/*int main()
{
	char dizi[] = "Bilgisayar";
	ft_memset(dizi, 'x', 5);
	printf("cdizi bellek içeriği: %s", dizi);

	return (0);
}*///Parametredeki b pointerına kopyalayacağımız dizi -18