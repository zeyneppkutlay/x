/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 16:02:57 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/18 16:32:33 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	i;
	size_t	j;

	i = 0;
	j = 0;
	while (dst[i] && i < size)
		i++;
	while (src[j] && (i + j + 1) < size)
	{
		dst[i + j] = src[j];
		j++;
	}
	if (i < size)
		dst[i + j] = '\0';
	return (i + ft_strlen(src));
}
/*
#include <string.h>
int main(void)
{
    char s1[10] = "Hello";
    char s2[8] = " World!";

printf("ft_strcat :: %s :: %zu :: sizeof %lu\n", s1,
 ft_strlcat(s1, s2, ft_strlen(s1)), ft_strlen(s1));
printf("strcat :: %s :: %zu :: sizeof %lu\n", s1, 
strlcat(s1, s2, ft_strlen(s1)), ft_strlen(s1));
}
*/