/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: zkutlay <zkutlay@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/22 15:18:03 by zkutlay           #+#    #+#             */
/*   Updated: 2022/10/23 13:47:37 by zkutlay          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

char	*ft_strrchr(const char *s, int c)
{
	int	i;

	i = ft_strlen(s);
	while (i >= 0)
	{
		if (s[i] == (char)c)
			return ((char *)(s + i));
		i--;
	}
	return (0);
}

/*int main()
{
	char a;
	a = "t";
	char *s= "Zeynep Kutlay";
	printf("%s", ft_strrchr(s, 2));
	//char *p = s + 2;
	//printf("%s - %s - %c",s+2 , p, *p);
	return (0);
}*/